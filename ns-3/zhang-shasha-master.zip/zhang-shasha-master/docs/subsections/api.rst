API
===

.. automodule:: zss

.. autofunction:: zss.simple_distance(A, B, get_children=zss.Node.get_distance, get_label=zss.Node.get_label, label_dist=strdist)

.. autofunction:: zss.distance

.. autoclass:: zss.Node
    :members:
